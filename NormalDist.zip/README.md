# NormalDist
HTML5的正态分布演示

> JS不是主业、技术不佳。